# Clinic Appointment System
---

**University of Windsor, COMP 3220 Team Project.**
`Fall 2026`
`Group 8`

## Group Members
| Name | GitHub username |
| --- | --- |
| `Michell Marchenko` | `@MichellMarchenko`|
| `Darin Ty` | `@tydarin`|
| `Gregory Eloi` | `@HalfasleepDev`|
| `Paul Tenzer` | ``|

## Build and run

Run these commands from the folder containing `pom.xml`. Install JDK 17 or newer and Maven first. The project was verified on Linux with JDK 21 and Maven 3.9.11.

```sh
mvn clean verify
mvn javafx:run
```

The first build and run can download dependencies. With those dependencies cached, both commands work offline.

```sh
mvn -o clean verify
mvn -o javafx:run
```

In Eclipse, import this folder as an **Existing Maven Project** and use the `javafx:run` Maven goal.

## Project files

- [src/main](src/main) contains the Java application and its JavaFX stylesheet.
- [src/test](src/test) contains the automated tests.
- [UML Diagrams](<UML Diagrams>) contains the editable initial class diagram, the booking scenario description, and its class, object, and sequence diagrams.

## Booking workflow

1. Use **Find patient** to select or edit a profile, or use **Add patient** to register one. Search by name, exact patient ID, or at least four phone digits.
2. Select a doctor and weekday in the booking form. The form shows the clinic's 16 half-hour starts, from 8:00 a.m. through 3:30 p.m. Booked or elapsed times are unavailable.
3. Select a time and choose **Book appointment**. The app confirms the booking after SQLite saves it.
4. Select an upcoming row to reschedule or cancel it. **Discard** exits rescheduling. Confirming a cancellation releases that time and retains the original appointment under **Cancelled**.
5. Use **Upcoming**, **Past**, **Cancelled**, or **All** to browse records. Filter by doctor or search by patient. **Previous** and **Next** move through the filtered results.

## Implementation changes

| Change | How it works and why |
|---|---|
| [Schedule and booking workspace](src/main/java/Main.java) | A date-ordered table sits beside the booking form, so staff can see the schedule while entering a booking. The form keeps all 16 times visible, distinguishes unavailable times, and provides a confirmation with the patient, doctor, and time before cancelling. |
| [JavaFX stylesheet](src/main/resources/clinic.css) | Shared spacing, field widths, focus outlines, and table styles make the controls consistent across the workspace and dialogs. The restrained colours reserve emphasis for the selected time, the primary action, and cancellation. The stylesheet ships with the app and uses the system font. |
| [Queries and storage](src/main/java/ClinicStore.java) | Patient search and appointment filters run before pagination in SQLite, so the results cover the whole database. Upcoming appointments start with the next slot and history starts with the most recent. The app requests up to 26 rows and displays 25 per page. A single background worker performs storage operations while the interface shows progress. |
| Cancellation and migration | The previous schema reserved each doctor/date/time combination for the life of the row. The migration copies existing bookings and their IDs into the new schema in one transaction. A unique index applies to rows that still hold a slot, so cancelling releases the slot without deleting its history. Cancelled records count toward the 2,000-appointment limit. |
| [Appointment state](src/main/java/Appointment.java) | Appointments retain typed dates, times, and IDs and carry their persisted cancellation state. The app excludes elapsed slots from new bookings. Rescheduling and cancelling check the original booking details in the write itself, so an old selection cannot overwrite a change made in another window. |
| [Build configuration](pom.xml) | The existing Maven build compiles for Java 17, launches with a 256 MB heap, and packages the stylesheet with the code. The launch uses cached dependencies offline. |
| [Regression tests](src/test/java/ClinicStoreTest.java) | Tests cover the calendar, search, filters, persistence, capacity, competing writes, stale edits, cancellation and slot reuse, and migration of existing databases. A failed migration test checks that the original appointment row is preserved. |

The app stores records in one `clinic.db` alongside `pom.xml`. SQLite may create a temporary recovery file while writing. The store enforces the 50 MB database limit, 500 patients, and 2,000 appointments, and checks the roster against 50 doctors and 10 specialties. To move records, close the app and copy the database alongside the project.

## Verification

- A clean offline Maven build passed all 11 tests, including a fixture with 50 doctors, 500 patients, and 2,000 appointments.
- The normal Maven launch was verified offline from a fresh copy of the source.
- An isolated JavaFX run under a 256 MB heap exercised patient search, unavailable slots, booking, rescheduling, both cancellation choices, and history. The interface was inspected with populated and empty schedules. The tests used synthetic records.

## AI usage record

OpenAI Codex assisted with the Java code, Maven configuration, JavaFX styling, regression tests, and verification. Source comments identify the affected code. The implementation notes above describe behaviour for code review. The team is responsible for its own PD3 analysis and design rationale and for the disclosure in its submitted report.
