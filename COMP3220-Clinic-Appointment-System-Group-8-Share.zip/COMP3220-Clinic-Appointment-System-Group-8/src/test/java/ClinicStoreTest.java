import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.Clock;
import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneOffset;
import java.time.temporal.TemporalAdjusters;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

// AI assistance: OpenAI Codex generated the booking, persistence, and migration regression tests.
class ClinicStoreTest {
    @TempDir
    Path directory;

    private Path database;
    private ClinicStore clinic;
    private final Clock clock = Clock.fixed(Instant.parse("2026-11-23T09:30:00Z"), ZoneOffset.UTC);
    private final LocalDate today = LocalDate.now(clock);
    private final LocalDate monday = today.with(TemporalAdjusters.next(DayOfWeek.MONDAY));
    private final LocalTime opening = LocalTime.of(8, 0);

    @BeforeEach
    void initialize() throws SQLException {
        database = directory.resolve("clinic.db");
        clinic = new ClinicStore(database, clock);
        assertEquals(3, clinic.initialize().size());
    }

    @Test
    void offersSixteenHalfHourWeekdaySlots() {
        List<LocalTime> slots = Appointment.slotsOn(monday);
        assertEquals(16, slots.size());
        assertEquals(opening, slots.get(0));
        assertEquals(LocalTime.of(15, 30), slots.get(15));
        for (int index = 0; index < slots.size(); index++) {
            assertEquals(opening.plusMinutes(index * 30L), slots.get(index));
        }
        assertEquals(slots, Appointment.slotsOn(monday.plusDays(4)));
        assertTrue(Appointment.slotsOn(monday.plusDays(5)).isEmpty());
        assertTrue(Appointment.slotsOn(monday.plusDays(6)).isEmpty());
    }

    @Test
    void reopensProfileAndBookingAndKeepsAppointmentIdentityDuringEdit() throws SQLException {
        Patient patient = createPatient();
        clinic.updatePatient(patient.getId(), "Test", "Updated", "5195550101", "2 Test Street");
        clinic.book(patient.getId(), 1, monday, opening);

        ClinicStore reopened = new ClinicStore(database, clock);
        assertEquals(3, reopened.initialize().size());
        assertEquals("Updated", reopened.patients("", 0).get(0).getLastName());
        Appointment appointment = allAppointments(reopened, 0).get(0);
        assertEquals(patient.getId(), appointment.getPatient().getId());
        assertEquals(opening, appointment.getTime());
        assertEquals(List.of(opening), reopened.bookedTimes(1, monday, 0));
        assertTrue(reopened.bookedTimes(1, monday, appointment.getId()).isEmpty());

        reopened.reschedule(appointment, 1, monday, opening.plusMinutes(30));
        Appointment updated = allAppointments(clinic, 0).get(0);
        assertEquals(appointment.getId(), updated.getId());
        assertEquals(opening.plusMinutes(30), updated.getTime());
        assertEquals(List.of(updated.getTime()), clinic.bookedTimes(1, monday, 0));
    }

    @Test
    void rejectsConflictingEditWithoutChangingEitherBooking() throws SQLException {
        Patient patient = createPatient();
        clinic.book(patient.getId(), 1, monday, opening);
        clinic.book(patient.getId(), 2, monday, opening);
        Appointment newest = appointments(ClinicStore.AppointmentView.ALL, 2, "").get(0);

        assertThrows(IllegalStateException.class,
                () -> clinic.reschedule(newest, 1, monday, opening));
        assertEquals(1, appointments(ClinicStore.AppointmentView.ALL, 2, "").size());
        assertEquals(List.of(opening), clinic.bookedTimes(1, monday, 0));
        assertEquals(List.of(opening), clinic.bookedTimes(2, monday, 0));
    }

    @Test
    void rejectsWeekendInvalidAndPastSlots() throws SQLException {
        int patientId = createPatient().getId();
        assertThrows(IllegalArgumentException.class,
                () -> clinic.book(patientId, 1, monday.plusDays(5), opening));
        assertThrows(IllegalArgumentException.class,
                () -> clinic.book(patientId, 1, monday, LocalTime.of(16, 0)));
        assertThrows(IllegalArgumentException.class,
                () -> clinic.book(patientId, 1, monday, LocalTime.of(8, 15)));
        assertThrows(IllegalArgumentException.class,
                () -> clinic.book(patientId, 1, today.minusDays(1), opening));
        assertThrows(IllegalArgumentException.class,
                () -> clinic.book(patientId, 1, today, opening));
        assertThrows(IllegalArgumentException.class,
                () -> clinic.book(patientId, 1, today, LocalTime.of(9, 30)));
        assertThrows(SQLException.class,
                () -> clinic.book(Integer.MAX_VALUE, 1, monday, opening));
        assertTrue(allAppointments(clinic, 0).isEmpty());
    }

    @Test
    void twoConcurrentWritesCanBookTheSameSlotOnlyOnce() throws Exception {
        int patientId = createPatient().getId();
        CountDownLatch ready = new CountDownLatch(2);
        CountDownLatch go = new CountDownLatch(1);
        Callable<Boolean> attempt = () -> {
            ready.countDown();
            assertTrue(go.await(3, TimeUnit.SECONDS));
            try {
                new ClinicStore(database, clock).book(patientId, 1, monday, opening);
                return true;
            } catch (IllegalStateException conflict) {
                assertEquals("This doctor is already booked at that date and time.", conflict.getMessage());
                return false;
            }
        };

        var workers = Executors.newFixedThreadPool(2);
        try {
            var first = workers.submit(attempt);
            var second = workers.submit(attempt);
            assertTrue(ready.await(3, TimeUnit.SECONDS));
            go.countDown();
            assertTrue(first.get(5, TimeUnit.SECONDS) ^ second.get(5, TimeUnit.SECONDS));
            assertEquals(1, allAppointments(clinic, 0).size());
        } finally {
            workers.shutdownNow();
        }
    }

    @Test
    void queriesStayPagedAtFullPatientAndAppointmentCapacity() throws SQLException {
        fillClinic();
        assertEquals(50, clinic.initialize().size());
        assertEquals(26, clinic.patients("", 0).size());
        assertEquals(25, clinic.patients("", 475).size());
        assertEquals(26, allAppointments(clinic, 0).size());
        assertEquals(25, allAppointments(clinic, 1_975).size());
        assertEquals(16, clinic.bookedTimes(1, monday, 0).size());
        assertThrows(IllegalStateException.class, this::createPatient);
        assertThrows(IllegalStateException.class, () ->
                clinic.book(1, 50, monday.plusDays(3), opening));
    }

    @Test
    void cancellationIsPersistedAndFreesTheSlot() throws SQLException {
        Patient patient = createPatient();
        clinic.book(patient.getId(), 1, monday, opening);
        Appointment booking = allAppointments(clinic, 0).get(0);
        clinic.cancel(booking);
        assertThrows(IllegalStateException.class, () -> clinic.cancel(booking));
        assertThrows(IllegalStateException.class, () ->
                clinic.reschedule(booking, 1, monday, opening.plusMinutes(30)));
        assertTrue(clinic.bookedTimes(1, monday, 0).isEmpty());
        clinic.book(patient.getId(), 1, monday, opening);
        var reopened = new ClinicStore(database, clock);
        var cancelled = reopened.appointments(ClinicStore.AppointmentView.CANCELLED, 0, "", 0);
        assertEquals(booking.getId(), cancelled.get(0).getId());
        assertTrue(cancelled.get(0).isCancelled());
        assertEquals(2, allAppointments(reopened, 0).size());
        assertEquals(List.of(opening), reopened.bookedTimes(1, monday, 0));
    }

    @Test
    void changingAnAppointmentInvalidatesItsOldSnapshot() throws SQLException {
        Patient patient = createPatient();
        clinic.book(patient.getId(), 1, monday, opening);
        Appointment original = allAppointments(clinic, 0).get(0);
        clinic.reschedule(original, 2, monday, opening.plusMinutes(30));
        assertThrows(IllegalStateException.class, () -> clinic.cancel(original));
        assertThrows(IllegalStateException.class, () ->
                clinic.reschedule(original, 1, monday, opening.plusMinutes(60)));
        assertEquals(2, allAppointments(clinic, 0).get(0).getDoctor().getId());
    }

    @Test
    void filtersScheduleByTimeDoctorAndPatient() throws SQLException {
        Patient one = createPatient();
        Patient two = clinic.createPatient("Jess", "Lee", "5195550199", "19 Test Street");
        try (var connection = DriverManager.getConnection("jdbc:sqlite:" + database);
             var insert = connection.prepareStatement("""
                     INSERT INTO appointments (patient_id, doctor_id, day, start_minute) VALUES (?, 1, ?, 480)
                     """)) {
            insert.setInt(1, one.getId());
            insert.setString(2, today.toString());
            insert.executeUpdate();
        }
        clinic.book(one.getId(), 1, today, LocalTime.of(11, 0));
        clinic.book(two.getId(), 2, monday, opening);
        assertEquals(1, appointments(ClinicStore.AppointmentView.PAST, 1, "test patient").size());
        assertEquals(2, appointments(ClinicStore.AppointmentView.UPCOMING, 0, "").size());
        assertEquals(two.getId(), appointments(ClinicStore.AppointmentView.UPCOMING, 2, "5550199")
                .get(0).getPatient().getId());
        assertTrue(appointments(ClinicStore.AppointmentView.UPCOMING, 1, "Lee").isEmpty());
        assertEquals(two.getId(), clinic.patients("Jess LEE", 0).get(0).getId());
        assertEquals(one.getId(), clinic.patients("1", 0).get(0).getId());
        assertTrue(clinic.patients("%", 0).isEmpty());
        Appointment past = appointments(ClinicStore.AppointmentView.PAST, 0, "").get(0);
        assertFalse(past.isCancelled());
        assertThrows(IllegalStateException.class, () -> clinic.cancel(past));
        assertThrows(IllegalStateException.class, () -> clinic.reschedule(past, 2, monday, opening.plusMinutes(30)));
    }

    @Test
    void migratesLegacyBookingsAndPreservesIds() throws SQLException {
        int patient = createPatient().getId();
        installLegacySchema(patient);
        assertEquals(3, clinic.initialize().size());
        assertEquals(3, clinic.initialize().size());
        Appointment booking = allAppointments(clinic, 0).get(0);
        assertEquals(77, booking.getId());
        assertEquals(patient, booking.getPatient().getId());
        assertEquals(monday, booking.getDate());
        assertFalse(booking.isCancelled());
        assertThrows(IllegalStateException.class, () -> clinic.book(patient, 1, monday, opening));
        clinic.cancel(booking);
        clinic.book(patient, 1, monday, opening);
        assertEquals(2, allAppointments(clinic, 0).size());
    }

    @Test
    void migrationFailurePreservesTheOriginalTable() throws SQLException {
        installLegacySchema(999);
        assertThrows(SQLException.class, clinic::initialize);
        try (var connection = DriverManager.getConnection("jdbc:sqlite:" + database);
             var statement = connection.createStatement();
             var rows = statement.executeQuery("SELECT id FROM appointments")) {
            assertTrue(rows.next());
            assertEquals(77, rows.getInt(1));
        }
    }

    private void installLegacySchema(int patient) throws SQLException {
        try (var connection = DriverManager.getConnection("jdbc:sqlite:" + database);
             var statement = connection.createStatement()) {
            statement.executeUpdate("DROP TABLE appointments");
            statement.execute("PRAGMA user_version = 0");
            statement.executeUpdate("""
                    CREATE TABLE appointments (
                        id INTEGER PRIMARY KEY,
                        patient_id INTEGER NOT NULL REFERENCES patients(id),
                        doctor_id INTEGER NOT NULL REFERENCES doctors(id),
                        day TEXT NOT NULL,
                        start_minute INTEGER NOT NULL,
                        UNIQUE(doctor_id, day, start_minute)
                    ) STRICT
                    """);
            try (var insert = connection.prepareStatement("INSERT INTO appointments VALUES (77, ?, 1, ?, 480)")) {
                insert.setInt(1, patient);
                insert.setString(2, monday.toString());
                insert.executeUpdate();
            }
        }
    }

    private static List<Appointment> allAppointments(ClinicStore store, int offset) throws SQLException {
        return store.appointments(ClinicStore.AppointmentView.ALL, 0, "", offset);
    }

    private List<Appointment> appointments(ClinicStore.AppointmentView view, int doctor, String search)
            throws SQLException {
        return clinic.appointments(view, doctor, search, 0);
    }

    private Patient createPatient() throws SQLException {
        return clinic.createPatient("Test", "Patient", "5195550100", "1 Test Street");
    }

    private void fillClinic() throws SQLException {
        try (var connection = DriverManager.getConnection("jdbc:sqlite:" + database);
             var statement = connection.createStatement()) {
            statement.execute("PRAGMA foreign_keys = ON");
            connection.setAutoCommit(false);
            statement.executeUpdate("""
                    WITH RECURSIVE ids(id) AS (SELECT 4 UNION ALL SELECT id + 1 FROM ids WHERE id < 50)
                    INSERT INTO doctors SELECT id, 'Test doctor ' || id, 'Test specialty ' || (id % 7) FROM ids
                    """);
            statement.executeUpdate("""
                    WITH RECURSIVE ids(id) AS (SELECT 1 UNION ALL SELECT id + 1 FROM ids WHERE id < 500)
                    INSERT INTO patients SELECT id, 'Test', 'Patient', '5195550100', '1 Test Street' FROM ids
                    """);
            try (var insert = connection.prepareStatement("""
                    INSERT INTO appointments (patient_id, doctor_id, day, start_minute) VALUES (?, ?, ?, ?)
                    """)) {
                for (int index = 0; index < 2_000; index++) {
                    insert.setInt(1, index % 500 + 1);
                    insert.setInt(2, (index / 16) % 50 + 1);
                    insert.setString(3, monday.plusDays(index / 800).toString());
                    insert.setInt(4, 480 + (index % 16) * 30);
                    insert.addBatch();
                }
                insert.executeBatch();
            }
            connection.commit();
        }
    }
}
