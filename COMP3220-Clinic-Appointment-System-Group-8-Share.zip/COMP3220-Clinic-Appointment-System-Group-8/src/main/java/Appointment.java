import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.stream.IntStream;

// AI assistance: OpenAI Codex generated the typed fields, slot rules, and cancellation state.
public final class Appointment {
    private static final DateTimeFormatter TIME_FORMAT =
            DateTimeFormatter.ofPattern("h:mm a", Locale.ROOT);
    private static final LocalTime OPENING_TIME = LocalTime.of(8, 0);
    private static final List<LocalTime> SLOTS = IntStream.range(0, 16)
            .mapToObj(index -> OPENING_TIME.plusMinutes(30L * index))
            .toList();

    private final int id;
    private final Patient patient;
    private final Doctor doctor;
    private final LocalDate date;
    private final LocalTime time;
    private final boolean cancelled;

    public Appointment(int id, Patient patient, Doctor doctor, LocalDate date, LocalTime time) {
        this(id, patient, doctor, date, time, false);
    }

    Appointment(int id, Patient patient, Doctor doctor, LocalDate date, LocalTime time, boolean cancelled) {
        this.id = id;
        this.patient = patient;
        this.doctor = doctor;
        this.date = date;
        this.time = time;
        this.cancelled = cancelled;
    }

    public int getId() {
        return id;
    }

    public Patient getPatient() {
        return patient;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public LocalDate getDate() {
        return date;
    }

    public LocalTime getTime() {
        return time;
    }

    public boolean isCancelled() {
        return cancelled;
    }

    public boolean isUpcoming(LocalDateTime now) {
        return !cancelled && date.atTime(time).isAfter(now);
    }

    static List<LocalTime> weekdaySlots() {
        return SLOTS;
    }

    static List<LocalTime> slotsOn(LocalDate date) {
        DayOfWeek day = date.getDayOfWeek();
        return day == DayOfWeek.SATURDAY || day == DayOfWeek.SUNDAY ? List.of() : SLOTS;
    }

    static String formatTime(LocalTime time) {
        return TIME_FORMAT.format(time);
    }

    @Override
    public String toString() {
        return date + " at " + formatTime(time) + " · " + doctor.getName()
                + " · Patient #" + patient.getId();
    }
}
