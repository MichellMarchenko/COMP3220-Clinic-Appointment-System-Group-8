import javafx.application.Application;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.concurrent.Task;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.nio.file.Path;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;
import java.util.function.Function;

// AI assistance: OpenAI Codex generated the scheduling workspace, dialogs, and event handlers.
public class Main extends Application {
    private static final DateTimeFormatter DISPLAY_DATE =
            DateTimeFormatter.ofPattern("EEE, MMM d, uuuu", Locale.CANADA);
    private static final String STYLESHEET = Main.class.getResource("/clinic.css").toExternalForm();

    private final ClinicStore store = new ClinicStore(Path.of("clinic.db"));
    private final ExecutorService databaseWorker = Executors.newSingleThreadExecutor(task -> {
        Thread thread = new Thread(task, "clinic-database");
        thread.setDaemon(true);
        return thread;
    });
    private final BooleanProperty busy = new SimpleBooleanProperty();
    private final BooleanProperty ready = new SimpleBooleanProperty();
    private final BooleanProperty editing = new SimpleBooleanProperty();

    private final Label status = new Label();
    private final Label pageNumber = new Label();
    private final TableView<Appointment> appointmentTable = new TableView<>();
    private final TextField scheduleSearch = new TextField();
    private final ComboBox<String> doctorFilter = new ComboBox<>();
    private final Button previousAppointments = new Button("Previous");
    private final Button nextAppointments = new Button("Next");

    private final Label formTitle = new Label("New appointment");
    private final Label patientName = new Label("No patient selected");
    private final Label patientContact = new Label();
    private final ComboBox<Doctor> doctorChoice = new ComboBox<>();
    private final DatePicker datePicker = new DatePicker();
    private final GridPane slotGrid = new GridPane();
    private final Label slotNote = new Label();
    private final Label formFeedback = new Label();

    private ClinicStore.AppointmentView view = ClinicStore.AppointmentView.UPCOMING;
    private List<Doctor> doctors = List.of();
    private String scheduleQuery = "";
    private int appointmentOffset;
    private boolean fillingForm;
    private Patient selectedPatient;
    private LocalTime selectedTime;
    private Appointment appointmentBeingEdited;

    @Override
    public void start(Stage stage) {
        Label title = new Label("Clinic Appointment System");
        title.getStyleClass().add("app-title");
        HBox header = new HBox(title);
        header.getStyleClass().add("app-header");

        VBox schedule = schedulePane(stage);
        ScrollPane booking = new ScrollPane(bookingPane(stage));
        booking.setFitToWidth(true);
        booking.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        booking.getStyleClass().add("booking-scroll");
        booking.setPrefWidth(344);
        booking.setMinWidth(344);
        HBox workspace = new HBox(schedule, booking);
        HBox.setHgrow(schedule, Priority.ALWAYS);
        workspace.disableProperty().bind(busy.or(ready.not()));

        Button retry = new Button("Retry");
        retry.visibleProperty().bind(ready.not().and(busy.not()));
        retry.managedProperty().bind(retry.visibleProperty());
        retry.setOnAction(event -> initializeClinic());
        HBox statusBar = new HBox(10, status, retry);
        statusBar.getStyleClass().add("status-bar");

        BorderPane root = new BorderPane(workspace, header, null, statusBar, null);
        stage.setTitle("Clinic Appointment System");
        stage.setScene(styledScene(root, 1160, 720));
        stage.setMinWidth(960);
        stage.setMinHeight(650);
        guardCloseWhileBusy(stage);
        stage.show();
        initializeClinic();
    }

    private VBox schedulePane(Stage owner) {
        Label title = sectionTitle("Appointments");
        ToggleGroup views = new ToggleGroup();
        HBox tabs = new HBox(4,
                viewTab("Upcoming", ClinicStore.AppointmentView.UPCOMING, views),
                viewTab("Past", ClinicStore.AppointmentView.PAST, views),
                viewTab("Cancelled", ClinicStore.AppointmentView.CANCELLED, views),
                viewTab("All", ClinicStore.AppointmentView.ALL, views));

        scheduleSearch.setPromptText("Patient name, ID or phone");
        scheduleSearch.setAccessibleText("Search appointments by patient");
        HBox.setHgrow(scheduleSearch, Priority.ALWAYS);
        Button search = new Button("Search");
        search.setOnAction(event -> searchSchedule());
        scheduleSearch.setOnAction(event -> searchSchedule());

        doctorFilter.setAccessibleText("Filter appointments by doctor");
        doctorFilter.setPrefWidth(156);
        doctorFilter.setOnAction(event -> {
            if (ready.get()) {
                loadAppointments(0, "");
            }
        });
        Button refresh = new Button("Refresh");
        refresh.setOnAction(event -> loadAppointments(appointmentOffset, ""));
        HBox filters = new HBox(8, scheduleSearch, search, doctorFilter, refresh);
        filters.setAlignment(Pos.CENTER_LEFT);

        appointmentTable.setAccessibleText("Appointments");
        appointmentTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        appointmentTable.setFixedCellSize(38);
        appointmentTable.setPlaceholder(new Label("No upcoming appointments"));
        appointmentTable.getColumns().addAll(List.of(
                column("Date", 130, appointment -> DISPLAY_DATE.format(appointment.getDate())),
                column("Time", 76, appointment -> Appointment.formatTime(appointment.getTime())),
                column("Patient", 139, appointment -> patientFullName(appointment.getPatient())),
                column("Doctor", 105, appointment -> appointment.getDoctor().getName()),
                column("Status", 76, this::appointmentStatus)));
        VBox.setVgrow(appointmentTable, Priority.ALWAYS);

        Button reschedule = new Button("Reschedule");
        Button cancel = new Button("Cancel appointment");
        cancel.getStyleClass().add("quiet-danger");
        reschedule.setDisable(true);
        cancel.setDisable(true);
        appointmentTable.getSelectionModel().selectedItemProperty().addListener(
                (observable, before, after) -> updateAppointmentActions(reschedule, cancel));
        editing.addListener((observable, before, after) -> updateAppointmentActions(reschedule, cancel));
        reschedule.setOnAction(event -> beginEdit(appointmentTable.getSelectionModel().getSelectedItem()));
        cancel.setOnAction(event -> confirmCancellation(owner, appointmentTable.getSelectionModel().getSelectedItem()));

        previousAppointments.setDisable(true);
        nextAppointments.setDisable(true);
        previousAppointments.setOnAction(event -> loadAppointments(appointmentOffset - ClinicStore.PAGE_SIZE, ""));
        nextAppointments.setOnAction(event -> loadAppointments(appointmentOffset + ClinicStore.PAGE_SIZE, ""));
        HBox footer = new HBox(8, reschedule, cancel, spacer(), pageNumber,
                previousAppointments, nextAppointments);
        footer.setAlignment(Pos.CENTER_LEFT);
        pageNumber.getStyleClass().add("muted");

        VBox pane = new VBox(12, title, tabs, filters, appointmentTable, footer);
        pane.getStyleClass().add("schedule-pane");
        return pane;
    }

    private VBox bookingPane(Stage owner) {
        formTitle.getStyleClass().add("section-title");
        patientName.getStyleClass().add("patient-name");
        patientContact.getStyleClass().add("muted");
        patientContact.setWrapText(true);
        patientContact.setManaged(false);
        patientContact.setVisible(false);
        VBox patient = new VBox(3, patientName, patientContact);
        patient.getStyleClass().add("patient-summary");
        Button findPatient = new Button("Find patient");
        findPatient.disableProperty().bind(editing);
        findPatient.setOnAction(event -> showPatients(owner));
        Button newPatient = new Button("Add patient");
        newPatient.disableProperty().bind(editing);
        newPatient.setOnAction(event -> showPatientEditor(owner, null, saved -> {
            setPatient(saved);
            message(formFeedback, "Patient #" + saved.getId() + " added.", false);
        }));

        doctorChoice.setPromptText("Select doctor");
        doctorChoice.setButtonCell(new ListCell<>() {
            @Override
            protected void updateItem(Doctor doctor, boolean empty) {
                super.updateItem(doctor, empty);
                setText(doctor == null ? doctorChoice.getPromptText() : doctor.toString());
                getStyleClass().remove("muted");
                if (doctor == null) {
                    getStyleClass().add("muted");
                }
            }
        });
        doctorChoice.setMaxWidth(Double.MAX_VALUE);
        datePicker.setPromptText("Select date");
        datePicker.setMaxWidth(Double.MAX_VALUE);
        datePicker.setEditable(false);
        datePicker.setDayCellFactory(picker -> new DateCell() {
            @Override
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                setDisable(empty || date == null || date.isBefore(LocalDate.now())
                        || Appointment.slotsOn(date).isEmpty());
            }
        });
        doctorChoice.valueProperty().addListener((observable, before, after) -> changeSlotContext());
        datePicker.valueProperty().addListener((observable, before, after) -> changeSlotContext());

        slotGrid.setHgap(6);
        slotGrid.setVgap(6);
        slotGrid.setMinHeight(138);
        for (int i = 0; i < 4; i++) {
            ColumnConstraints column = new ColumnConstraints();
            column.setPercentWidth(25);
            slotGrid.getColumnConstraints().add(column);
        }
        slotNote.getStyleClass().add("muted");
        slotNote.setWrapText(true);
        showSlots(null, List.of());

        Button save = new Button("Book appointment");
        save.getStyleClass().add("primary");
        save.setOnAction(event -> saveBooking());
        Button discard = new Button("Discard");
        discard.visibleProperty().bind(editing);
        discard.managedProperty().bind(editing);
        discard.setOnAction(event -> {
            clearBooking();
            message(formFeedback, "Changes discarded.", false);
        });
        editing.addListener((observable, before, after) -> {
            save.setText(after ? "Save changes" : "Book appointment");
            formTitle.setText(after ? "Reschedule" : "New appointment");
        });

        formFeedback.setWrapText(true);
        VBox pane = new VBox(9, formTitle, fieldLabel("Patient", null), patient,
                new HBox(8, findPatient, newPatient), fieldLabel("Doctor", doctorChoice), doctorChoice,
                fieldLabel("Date", datePicker), datePicker, fieldLabel("Time", slotGrid),
                slotNote, slotGrid, new HBox(8, save, discard), formFeedback);
        pane.getStyleClass().add("booking-pane");
        return pane;
    }

    @Override
    public void stop() {
        databaseWorker.shutdown();
    }

    private void initializeClinic() {
        submit(status, "Opening clinic database…", store::initialize, roster -> {
            doctors = roster;
            doctorChoice.getItems().setAll(doctors);
            doctorFilter.getItems().setAll("All doctors");
            doctors.forEach(doctor -> doctorFilter.getItems().add(doctor.getName()));
            doctorFilter.getSelectionModel().select(0);
            ready.set(true);
            loadAppointments(0, "Clinic ready.");
        });
    }

    private ToggleButton viewTab(String title, ClinicStore.AppointmentView tabView, ToggleGroup group) {
        ToggleButton tab = new ToggleButton(title);
        tab.getStyleClass().add("view-tab");
        tab.setToggleGroup(group);
        tab.setSelected(tabView == view);
        tab.setOnAction(event -> {
            tab.setSelected(true);
            if (tabView != view) {
                view = tabView;
                loadAppointments(0, "");
            }
        });
        return tab;
    }

    private void searchSchedule() {
        scheduleQuery = scheduleSearch.getText();
        loadAppointments(0, "");
    }

    private void loadAppointments(int offset, String confirmation) {
        loadAppointments(offset, confirmation, () -> {});
    }

    private void loadAppointments(int offset, String confirmation, Runnable loaded) {
        int filterIndex = doctorFilter.getSelectionModel().getSelectedIndex();
        int doctorId = filterIndex > 0 ? doctors.get(filterIndex - 1).getId() : 0;
        ClinicStore.AppointmentView requestedView = view;
        String query = scheduleQuery;
        String loading = confirmation.isEmpty() ? "Loading appointments…"
                : confirmation + " Refreshing appointments…";
        submit(status, loading, () -> store.appointments(requestedView, doctorId, query, offset), rows -> {
            if (rows.isEmpty() && offset > 0) {
                loadAppointments(0, confirmation, loaded);
                return;
            }
            appointmentOffset = offset;
            appointmentTable.getSelectionModel().clearSelection();
            appointmentTable.getItems().setAll(page(rows));
            String empty = query.isBlank() && doctorId == 0 ? switch (requestedView) {
                case UPCOMING -> "No upcoming appointments";
                case PAST -> "No past appointments";
                case CANCELLED -> "No cancelled appointments";
                case ALL -> "No appointments";
            } : "No matching appointments";
            appointmentTable.setPlaceholder(new Label(empty));
            pageNumber.setText("Page " + (offset / ClinicStore.PAGE_SIZE + 1));
            previousAppointments.setDisable(offset == 0);
            nextAppointments.setDisable(rows.size() <= ClinicStore.PAGE_SIZE);
            message(status, confirmation.isEmpty() ? "Appointments loaded." : confirmation, false);
            loaded.run();
        });
    }

    private String appointmentStatus(Appointment appointment) {
        if (appointment.isCancelled()) {
            return "Cancelled";
        }
        return appointment.isUpcoming(LocalDateTime.now()) ? "Upcoming" : "Past";
    }

    private void updateAppointmentActions(Button reschedule, Button cancel) {
        Appointment selected = appointmentTable.getSelectionModel().getSelectedItem();
        boolean blocked = editing.get() || selected == null || !selected.isUpcoming(LocalDateTime.now());
        reschedule.setDisable(blocked);
        cancel.setDisable(blocked);
    }

    private void showPatients(Stage owner) {
        TableView<Patient> patients = new TableView<>();
        patients.setAccessibleText("Patient directory");
        patients.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        patients.setFixedCellSize(34);
        patients.getColumns().addAll(List.of(
                column("ID", 54, patient -> Integer.toString(patient.getId())),
                column("Name", 200, Main::patientFullName),
                column("Phone", 112, Patient::getPhone)));
        VBox.setVgrow(patients, Priority.ALWAYS);
        TextField searchField = new TextField();
        searchField.setPromptText("Name, ID or phone");
        searchField.setAccessibleText("Search patients");
        HBox.setHgrow(searchField, Priority.ALWAYS);
        Button search = new Button("Search");
        Button previous = new Button("Previous");
        Button next = new Button("Next");
        Button select = new Button("Select patient");
        select.getStyleClass().add("primary");
        Button edit = new Button("Edit profile");
        Button close = new Button("Close");
        Label feedback = new Label();
        VBox contents = new VBox(10, new HBox(8, searchField, search), patients,
                new HBox(8, select, edit, close, spacer(), previous, next));
        contents.disableProperty().bind(busy);
        VBox.setVgrow(contents, Priority.ALWAYS);
        Stage dialog = dialog(owner, "Patients", new VBox(10, contents, feedback), 610, 430);

        Runnable runSearch = () -> loadPatients(patients, previous, next, feedback, searchField.getText(), 0);
        search.setOnAction(event -> runSearch.run());
        searchField.setOnAction(event -> runSearch.run());
        select.disableProperty().bind(patients.getSelectionModel().selectedItemProperty().isNull());
        edit.disableProperty().bind(select.disableProperty());
        select.setOnAction(event -> {
            setPatient(patients.getSelectionModel().getSelectedItem());
            dialog.close();
        });
        BooleanProperty profileChanged = new SimpleBooleanProperty();
        edit.setOnAction(event -> showPatientEditor(dialog, patients.getSelectionModel().getSelectedItem(), saved -> {
            profileChanged.set(true);
            if (selectedPatient != null && selectedPatient.getId() == saved.getId()) {
                setPatient(saved);
            }
            runSearch.run();
        }));
        patients.setOnMouseClicked(event -> {
            if (event.getClickCount() == 2 && !select.isDisabled()) {
                select.fire();
            }
        });
        close.setOnAction(event -> dialog.close());
        dialog.setOnHidden(event -> {
            if (profileChanged.get()) {
                loadAppointments(appointmentOffset, "Patient profile updated.");
            }
        });
        dialog.show();
        searchField.requestFocus();
        runSearch.run();
    }

    private void loadPatients(TableView<Patient> patients, Button previous, Button next, Label feedback,
                              String search, int offset) {
        submit(feedback, "Loading patients…", () -> store.patients(search, offset), rows -> {
            patients.getSelectionModel().clearSelection();
            patients.getItems().setAll(page(rows));
            patients.setPlaceholder(new Label(search.isBlank() ? "No patient profiles" : "No matching patients"));
            previous.setDisable(offset == 0);
            next.setDisable(rows.size() <= ClinicStore.PAGE_SIZE);
            previous.setOnAction(event -> loadPatients(patients, previous, next, feedback,
                    search, offset - ClinicStore.PAGE_SIZE));
            next.setOnAction(event -> loadPatients(patients, previous, next, feedback,
                    search, offset + ClinicStore.PAGE_SIZE));
            message(feedback, "Page " + (offset / ClinicStore.PAGE_SIZE + 1), false);
        });
    }

    private void showPatientEditor(Stage owner, Patient patient, Consumer<Patient> saved) {
        boolean creating = patient == null;
        TextField firstName = new TextField(creating ? "" : patient.getFirstName());
        TextField lastName = new TextField(creating ? "" : patient.getLastName());
        TextField phone = new TextField(creating ? "" : patient.getPhone());
        TextField address = new TextField(creating ? "" : patient.getAddress());
        VBox form = new VBox(7, fieldLabel("First name", firstName), firstName, fieldLabel("Last name", lastName),
                lastName, fieldLabel("Phone", phone), phone, fieldLabel("Address", address), address);

        Button save = new Button(creating ? "Add patient" : "Save changes");
        save.getStyleClass().add("primary");
        save.setDefaultButton(true);
        Button close = new Button("Cancel");
        close.setCancelButton(true);
        Label feedback = new Label();
        feedback.setWrapText(true);
        VBox contents = new VBox(14, form, new HBox(8, save, close));
        contents.disableProperty().bind(busy);
        VBox root = new VBox(10, contents, feedback);
        Stage dialog = dialog(owner, creating ? "Add patient" : "Edit profile", root, 410, 365);
        save.setOnAction(event -> {
            String first = firstName.getText().strip();
            String last = lastName.getText().strip();
            String number = phone.getText().strip();
            String street = address.getText().strip();
            if (first.isEmpty() || last.isEmpty() || number.isEmpty() || street.isEmpty()) {
                message(feedback, "Complete all four fields.", true);
                return;
            }
            if (!number.matches("[0-9]{10}")) {
                message(feedback, "Enter a 10-digit phone number.", true);
                phone.requestFocus();
                return;
            }
            submit(feedback, "Saving patient profile…",
                    () -> creating ? store.createPatient(first, last, number, street)
                            : store.updatePatient(patient.getId(), first, last, number, street),
                    updated -> {
                        dialog.close();
                        saved.accept(updated);
                    });
        });
        close.setOnAction(event -> dialog.close());
        dialog.show();
        firstName.requestFocus();
    }

    private void changeSlotContext() {
        if (!fillingForm) {
            selectedTime = null;
            message(formFeedback, "", false);
            loadSlots();
        }
    }

    private void loadSlots() {
        slotGrid.getChildren().clear();
        Doctor doctor = doctorChoice.getValue();
        LocalDate date = datePicker.getValue();
        if (doctor == null || date == null) {
            showSlots(null, List.of());
            return;
        }
        int editingId = appointmentBeingEdited == null ? 0 : appointmentBeingEdited.getId();
        submit(slotNote, "Checking availability…", () -> store.bookedTimes(doctor.getId(), date, editingId),
                booked -> showSlots(date, booked));
    }

    private void showSlots(LocalDate date, List<LocalTime> booked) {
        slotGrid.getChildren().clear();
        ToggleGroup times = new ToggleGroup();
        LocalDateTime now = LocalDateTime.now();
        List<LocalTime> slots = date == null ? Appointment.weekdaySlots() : Appointment.slotsOn(date);
        int open = 0;
        for (int index = 0; index < slots.size(); index++) {
            LocalTime time = slots.get(index);
            boolean taken = booked.contains(time);
            boolean elapsed = date != null && !date.atTime(time).isAfter(now);
            ToggleButton slot = new ToggleButton(Appointment.formatTime(time));
            slot.getStyleClass().add("time-slot");
            slot.setMaxWidth(Double.MAX_VALUE);
            slot.setToggleGroup(times);
            slot.setDisable(date == null || taken || elapsed);
            if (taken || elapsed) {
                String reason = taken ? "Booked" : "Time has passed";
                slot.setTooltip(new Tooltip(reason));
                slot.setAccessibleText(slot.getText() + ", " + reason);
            } else if (!slot.isDisabled()) {
                open++;
                slot.setSelected(time.equals(selectedTime));
            }
            slot.setOnAction(event -> {
                slot.setSelected(true);
                selectedTime = time;
                message(formFeedback, "", false);
            });
            slotGrid.add(slot, index % 4, index / 4);
        }
        if (times.getSelectedToggle() == null) {
            selectedTime = null;
        }
        String summary = date == null ? "Choose a doctor and date." : switch (open) {
            case 0 -> "No times available";
            case 1 -> "1 time available";
            default -> open + " times available";
        };
        message(slotNote, summary, false);
    }

    private void beginEdit(Appointment appointment) {
        if (!appointment.isUpcoming(LocalDateTime.now())) {
            message(status, "Only upcoming appointments can be rescheduled.", true);
            return;
        }
        appointmentBeingEdited = appointment;
        editing.set(true);
        fillingForm = true;
        setPatient(appointment.getPatient());
        doctors.stream().filter(doctor -> doctor.getId() == appointment.getDoctor().getId())
                .findFirst().ifPresent(doctorChoice::setValue);
        datePicker.setValue(appointment.getDate());
        selectedTime = appointment.getTime();
        fillingForm = false;
        message(formFeedback, "Editing appointment #" + appointment.getId() + ".", false);
        loadSlots();
    }

    private void saveBooking() {
        if (selectedPatient == null) {
            message(formFeedback, "Select a patient.", true);
            return;
        }
        Doctor doctor = doctorChoice.getValue();
        LocalDate date = datePicker.getValue();
        LocalTime time = selectedTime;
        if (doctor == null || date == null || time == null) {
            message(formFeedback, "Select a doctor, date and time.", true);
            return;
        }
        Appointment original = appointmentBeingEdited;
        int patientId = selectedPatient.getId();
        submit(formFeedback, "Saving appointment…", () -> {
            if (original == null) {
                store.book(patientId, doctor.getId(), date, time);
            } else {
                store.reschedule(original, doctor.getId(), date, time);
            }
            return null;
        }, saved -> {
            clearBooking();
            String confirmation = original == null ? "Appointment booked." : "Appointment rescheduled.";
            loadAppointments(0, confirmation);
        });
    }

    private void confirmCancellation(Stage owner, Appointment appointment) {
        if (!appointment.isUpcoming(LocalDateTime.now())) {
            message(status, "Only upcoming appointments can be cancelled.", true);
            return;
        }
        Label details = new Label(patientFullName(appointment.getPatient()) + " with "
                + appointment.getDoctor().getName() + "\n" + DISPLAY_DATE.format(appointment.getDate())
                + " at " + Appointment.formatTime(appointment.getTime()));
        details.setWrapText(true);
        Button keep = new Button("Keep appointment");
        keep.setCancelButton(true);
        Button cancel = new Button("Cancel appointment");
        cancel.getStyleClass().add("danger");
        Label feedback = new Label();
        feedback.setWrapText(true);
        HBox actions = new HBox(8, keep, cancel);
        actions.disableProperty().bind(busy);
        Label effect = new Label("Cancelling will make this time available for another booking.");
        effect.setWrapText(true);
        effect.getStyleClass().add("muted");
        Stage dialog = dialog(owner, "Cancel appointment?", new VBox(12, details, effect, actions, feedback),
                440, 173);
        keep.setOnAction(event -> dialog.close());
        cancel.setOnAction(event -> submit(feedback, "Cancelling appointment…", () -> {
            store.cancel(appointment);
            return null;
        }, saved -> {
            dialog.close();
            loadAppointments(appointmentOffset, "Appointment cancelled.", () -> {
                Doctor doctor = doctorChoice.getValue();
                if (doctor != null && doctor.getId() == appointment.getDoctor().getId()
                        && appointment.getDate().equals(datePicker.getValue())) {
                    loadSlots();
                }
            });
        }));
        dialog.show();
        keep.requestFocus();
    }

    private void clearBooking() {
        appointmentBeingEdited = null;
        editing.set(false);
        fillingForm = true;
        setPatient(null);
        doctorChoice.setValue(null);
        datePicker.setValue(null);
        fillingForm = false;
        selectedTime = null;
        showSlots(null, List.of());
        message(formFeedback, "", false);
    }

    private void setPatient(Patient patient) {
        selectedPatient = patient;
        patientName.setText(patient == null ? "No patient selected" : patientFullName(patient));
        patientContact.setText(patient == null ? "" : "Patient #" + patient.getId() + "  ·  " + patient.getPhone());
        patientContact.setManaged(patient != null);
        patientContact.setVisible(patient != null);
    }

    private Stage dialog(Stage owner, String title, Parent content, double width, double height) {
        Stage dialog = new Stage();
        dialog.initOwner(owner);
        dialog.initModality(Modality.WINDOW_MODAL);
        dialog.setTitle(title);
        VBox root = new VBox(content);
        VBox.setVgrow(content, Priority.ALWAYS);
        root.getStyleClass().add("dialog-pane-local");
        dialog.setScene(styledScene(root, width, height));
        dialog.setMinWidth(width);
        dialog.setMinHeight(height);
        guardCloseWhileBusy(dialog);
        return dialog;
    }

    private void guardCloseWhileBusy(Stage stage) {
        stage.setOnCloseRequest(event -> {
            if (busy.get()) {
                event.consume();
            }
        });
    }

    private <T> void submit(Label feedback, String progress, Callable<T> work, Consumer<T> done) {
        if (busy.get()) {
            return;
        }
        busy.set(true);
        message(feedback, progress, false);
        Task<T> task = new Task<>() {
            @Override
            protected T call() throws Exception {
                return work.call();
            }
        };
        task.setOnSucceeded(event -> {
            busy.set(false);
            done.accept(task.getValue());
        });
        task.setOnFailed(event -> {
            busy.set(false);
            Throwable error = task.getException();
            if ((error instanceof IllegalArgumentException || error instanceof IllegalStateException)
                    && error.getMessage() != null) {
                message(feedback, error.getMessage(), true);
            } else if (error instanceof SQLException sqlError && (sqlError.getErrorCode() & 255) == 5) {
                message(feedback, "Clinic data is busy. Try again.", true);
            } else {
                message(feedback, "Could not access clinic data. Check that clinic.db is writable.", true);
                System.err.println("Clinic data operation failed: " + error.getClass().getSimpleName());
            }
        });
        databaseWorker.execute(task);
    }

    private static void message(Label label, String text, boolean error) {
        label.setText(text);
        label.getStyleClass().remove("error-text");
        if (error) {
            label.getStyleClass().add("error-text");
        }
    }

    private static <T> List<T> page(List<T> rows) {
        return rows.subList(0, Math.min(rows.size(), ClinicStore.PAGE_SIZE));
    }

    private static <T> TableColumn<T, String> column(String title, double width, Function<T, String> value) {
        TableColumn<T, String> column = new TableColumn<>(title);
        column.setCellValueFactory(cell -> new ReadOnlyStringWrapper(value.apply(cell.getValue())));
        column.setPrefWidth(width);
        column.setMinWidth(width * 0.78);
        column.setSortable(false);
        column.setReorderable(false);
        return column;
    }

    private static String patientFullName(Patient patient) {
        return patient.getFirstName() + " " + patient.getLastName();
    }

    private static Label sectionTitle(String text) {
        Label title = new Label(text);
        title.getStyleClass().add("section-title");
        return title;
    }

    private static Label fieldLabel(String text, Node target) {
        Label label = new Label(text);
        label.getStyleClass().add("field-label");
        label.setLabelFor(target);
        return label;
    }

    private static Region spacer() {
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        return spacer;
    }

    private static Scene styledScene(Parent root, double width, double height) {
        Scene scene = new Scene(root, width, height);
        scene.getStylesheets().add(STYLESHEET);
        return scene;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
