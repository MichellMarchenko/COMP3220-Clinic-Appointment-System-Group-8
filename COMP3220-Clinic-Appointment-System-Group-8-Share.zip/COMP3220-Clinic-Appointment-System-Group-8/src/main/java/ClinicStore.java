import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import org.sqlite.SQLiteErrorCode;
import org.sqlite.SQLiteException;

// AI assistance: OpenAI Codex generated the SQLite migration, queries, and booking operations.
final class ClinicStore {
    static final int PAGE_SIZE = 25;
    private static final int MAX_PATIENTS = 500;
    private static final int MAX_APPOINTMENTS = 2_000;
    private static final int MAX_DATABASE_BYTES = 50_000_000;
    private static final String PATIENT_MATCH = """
            (?1 = '' OR CAST(p.id AS TEXT) = ?1
              OR instr(lower(p.first_name || ' ' || p.last_name), lower(?1)) > 0
              OR (length(?1) >= 4 AND instr(p.phone, ?1) > 0))
            """;

    enum AppointmentView {
        UPCOMING, PAST, CANCELLED, ALL
    }

    private final String url;
    private final Clock clock;

    ClinicStore(Path database) {
        this(database, Clock.systemDefaultZone());
    }

    ClinicStore(Path database, Clock clock) {
        this.url = "jdbc:sqlite:" + database.toAbsolutePath();
        this.clock = clock;
    }

    List<Doctor> initialize() throws SQLException {
        try (Connection connection = open(); Statement statement = connection.createStatement()) {
            statement.execute("BEGIN IMMEDIATE");
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS patients (
                        id INTEGER PRIMARY KEY,
                        first_name TEXT NOT NULL CHECK (length(trim(first_name)) > 0),
                        last_name TEXT NOT NULL CHECK (length(trim(last_name)) > 0),
                        phone TEXT NOT NULL CHECK (length(phone) = 10 AND phone NOT GLOB '*[^0-9]*'),
                        address TEXT NOT NULL CHECK (length(trim(address)) > 0)
                    ) STRICT
                    """);
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS doctors (
                        id INTEGER PRIMARY KEY,
                        name TEXT NOT NULL,
                        specialty TEXT NOT NULL
                    ) STRICT
                    """);
            migrateAppointments(statement);
            statement.executeUpdate("""
                    INSERT INTO doctors (id, name, specialty) VALUES
                        (1, 'Dr. Smith', 'Family Medicine'),
                        (2, 'Dr. Brown', 'Cardiology'),
                        (3, 'Dr. Lee', 'Pediatrics')
                    ON CONFLICT (id) DO NOTHING
                    """);
            List<Doctor> doctors = new ArrayList<>();
            try (ResultSet rows = statement.executeQuery(
                    "SELECT id, name, specialty FROM doctors ORDER BY id LIMIT 51")) {
                while (rows.next()) {
                    doctors.add(readDoctor(rows, 1));
                }
            }
            if (doctors.size() > 50 || doctors.stream().map(Doctor::getSpecialty).distinct().count() > 10) {
                throw new IllegalStateException("The doctor roster exceeds the clinic's capacity.");
            }
            statement.execute("COMMIT");
            return doctors;
        }
    }

    private static void migrateAppointments(Statement statement) throws SQLException {
        int version;
        try (ResultSet rows = statement.executeQuery("PRAGMA user_version")) {
            rows.next();
            version = rows.getInt(1);
        }
        if (version == 1) {
            return;
        }
        if (version != 0) {
            throw new IllegalStateException("This database was created by a different version of the app.");
        }

        boolean legacy;
        try (ResultSet rows = statement.executeQuery(
                "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'appointments'")) {
            legacy = rows.next();
        }
        if (legacy) {
            statement.executeUpdate("ALTER TABLE appointments RENAME TO appointments_v0");
        }
        statement.executeUpdate("""
                CREATE TABLE appointments (
                    id INTEGER PRIMARY KEY,
                    patient_id INTEGER NOT NULL REFERENCES patients(id),
                    doctor_id INTEGER NOT NULL REFERENCES doctors(id),
                    day TEXT NOT NULL CHECK (
                        length(day) = 10 AND day IS date(day, '+0 days')
                        AND strftime('%w', day) IN ('1', '2', '3', '4', '5')
                    ),
                    start_minute INTEGER NOT NULL CHECK (
                        start_minute >= 480 AND start_minute < 960 AND start_minute % 30 = 0
                    ),
                    cancelled INTEGER NOT NULL DEFAULT 0 CHECK (cancelled IN (0, 1))
                ) STRICT
                """);
        if (legacy) {
            statement.executeUpdate("""
                    INSERT INTO appointments (id, patient_id, doctor_id, day, start_minute)
                    SELECT id, patient_id, doctor_id, day, start_minute FROM appointments_v0
                    """);
            statement.executeUpdate("DROP TABLE appointments_v0");
        }
        statement.executeUpdate("""
                CREATE UNIQUE INDEX active_doctor_slot ON appointments (doctor_id, day, start_minute)
                WHERE cancelled = 0
                """);
        statement.executeUpdate("""
                CREATE INDEX appointment_schedule ON appointments (cancelled, day, start_minute, id)
                """);
        statement.execute("PRAGMA user_version = 1");
    }

    List<Patient> patients(String search, int offset) throws SQLException {
        String sql = "SELECT p.id, p.first_name, p.last_name, p.phone, p.address FROM patients p WHERE "
                + PATIENT_MATCH + " ORDER BY p.last_name COLLATE NOCASE, p.first_name COLLATE NOCASE, p.id"
                + " LIMIT ?2 OFFSET ?3";
        try (Connection connection = open(); PreparedStatement query = connection.prepareStatement(sql)) {
            query.setString(1, search.strip());
            query.setInt(2, PAGE_SIZE + 1);
            query.setInt(3, offset);
            List<Patient> patients = new ArrayList<>();
            try (ResultSet rows = query.executeQuery()) {
                while (rows.next()) {
                    patients.add(readPatient(rows, 1));
                }
            }
            return patients;
        }
    }

    Patient createPatient(String firstName, String lastName, String phone, String address) throws SQLException {
        try (Connection connection = open();
             PreparedStatement insert = connection.prepareStatement("""
                     INSERT INTO patients (first_name, last_name, phone, address)
                     SELECT ?, ?, ?, ? WHERE (SELECT COUNT(*) FROM patients) < ?
                     RETURNING id
                     """)) {
            setPatientFields(insert, firstName, lastName, phone, address);
            insert.setInt(5, MAX_PATIENTS);
            try (ResultSet rows = insert.executeQuery()) {
                if (!rows.next()) {
                    throw new IllegalStateException("The clinic has reached its 500-patient capacity.");
                }
                return new Patient(rows.getInt(1), firstName, lastName, phone, address);
            }
        }
    }

    Patient updatePatient(int id, String firstName, String lastName, String phone, String address)
            throws SQLException {
        try (Connection connection = open();
             PreparedStatement update = connection.prepareStatement("""
                     UPDATE patients SET first_name = ?, last_name = ?, phone = ?, address = ?
                     WHERE id = ?
                     """)) {
            setPatientFields(update, firstName, lastName, phone, address);
            update.setInt(5, id);
            if (update.executeUpdate() == 0) {
                throw new IllegalStateException("That patient profile no longer exists.");
            }
            return new Patient(id, firstName, lastName, phone, address);
        }
    }

    List<Appointment> appointments(AppointmentView view, int doctorId, String search, int offset)
            throws SQLException {
        String status = switch (view) {
            case UPCOMING -> "a.cancelled = 0 AND (a.day, a.start_minute) > (?3, ?4)";
            case PAST -> "a.cancelled = 0 AND (a.day, a.start_minute) <= (?3, ?4)";
            case CANCELLED -> "a.cancelled = 1";
            case ALL -> "1";
        };
        String order = view == AppointmentView.UPCOMING ? "a.day, a.start_minute, a.id"
                : "a.day DESC, a.start_minute DESC, a.id DESC";
        String sql = """
                SELECT a.id, a.day, a.start_minute, p.id, p.first_name, p.last_name, p.phone, p.address,
                       d.id, d.name, d.specialty, a.cancelled
                FROM appointments a
                JOIN patients p ON p.id = a.patient_id
                JOIN doctors d ON d.id = a.doctor_id
                WHERE (?2 = 0 OR d.id = ?2) AND
                """ + PATIENT_MATCH + " AND " + status + " ORDER BY " + order + " LIMIT ?5 OFFSET ?6";
        LocalDateTime now = LocalDateTime.now(clock);
        try (Connection connection = open(); PreparedStatement query = connection.prepareStatement(sql)) {
            query.setString(1, search.strip());
            query.setInt(2, doctorId);
            if (view == AppointmentView.UPCOMING || view == AppointmentView.PAST) {
                setMoment(query, 3, now);
            }
            query.setInt(5, PAGE_SIZE + 1);
            query.setInt(6, offset);
            List<Appointment> appointments = new ArrayList<>();
            try (ResultSet rows = query.executeQuery()) {
                while (rows.next()) {
                    appointments.add(new Appointment(rows.getInt(1), readPatient(rows, 4), readDoctor(rows, 9),
                            LocalDate.parse(rows.getString(2)), fromMinute(rows.getInt(3)), rows.getBoolean(12)));
                }
            }
            return appointments;
        }
    }

    List<LocalTime> bookedTimes(int doctorId, LocalDate date, int editingId) throws SQLException {
        try (Connection connection = open();
             PreparedStatement query = connection.prepareStatement("""
                     SELECT start_minute FROM appointments
                     WHERE doctor_id = ? AND day = ? AND id <> ? AND cancelled = 0
                     ORDER BY start_minute
                     """)) {
            query.setInt(1, doctorId);
            query.setString(2, date.toString());
            query.setInt(3, editingId);
            List<LocalTime> times = new ArrayList<>();
            try (ResultSet rows = query.executeQuery()) {
                while (rows.next()) {
                    times.add(fromMinute(rows.getInt(1)));
                }
            }
            return times;
        }
    }

    void book(int patientId, int doctorId, LocalDate date, LocalTime time) throws SQLException {
        requireFutureSlot(date, time, LocalDateTime.now(clock));
        try (Connection connection = open();
             PreparedStatement write = connection.prepareStatement("""
                     INSERT INTO appointments (patient_id, doctor_id, day, start_minute)
                     SELECT ?, ?, ?, ? WHERE (SELECT COUNT(*) FROM appointments) < ?
                     """)) {
            write.setInt(1, patientId);
            write.setInt(2, doctorId);
            setMoment(write, 3, date.atTime(time));
            write.setInt(5, MAX_APPOINTMENTS);
            if (write.executeUpdate() == 0) {
                throw new IllegalStateException("The clinic has reached its 2,000-appointment capacity.");
            }
        } catch (SQLiteException error) {
            throw bookingConflict(error);
        }
    }

    void reschedule(Appointment existing, int doctorId, LocalDate date, LocalTime time) throws SQLException {
        LocalDateTime now = LocalDateTime.now(clock);
        requireFutureSlot(date, time, now);
        try (Connection connection = open();
             PreparedStatement write = connection.prepareStatement("""
                     UPDATE appointments SET doctor_id = ?, day = ?, start_minute = ?
                     WHERE id = ? AND patient_id = ? AND doctor_id = ? AND day = ? AND start_minute = ?
                       AND cancelled = 0 AND (day, start_minute) > (?, ?)
                     """)) {
            write.setInt(1, doctorId);
            setMoment(write, 2, date.atTime(time));
            changeUpcoming(write, 4, existing, now);
        } catch (SQLiteException error) {
            throw bookingConflict(error);
        }
    }

    void cancel(Appointment existing) throws SQLException {
        try (Connection connection = open();
             PreparedStatement write = connection.prepareStatement("""
                     UPDATE appointments SET cancelled = 1
                     WHERE id = ? AND patient_id = ? AND doctor_id = ? AND day = ? AND start_minute = ?
                       AND cancelled = 0 AND (day, start_minute) > (?, ?)
                     """)) {
            changeUpcoming(write, 1, existing, LocalDateTime.now(clock));
        }
    }

    private static void requireFutureSlot(LocalDate date, LocalTime time, LocalDateTime now) {
        if (!Appointment.slotsOn(date).contains(time) || !date.atTime(time).isAfter(now)) {
            throw new IllegalArgumentException("Choose a future half-hour slot during clinic hours.");
        }
    }

    private static void changeUpcoming(PreparedStatement write, int index, Appointment existing, LocalDateTime now)
            throws SQLException {
        write.setInt(index, existing.getId());
        write.setInt(index + 1, existing.getPatient().getId());
        write.setInt(index + 2, existing.getDoctor().getId());
        setMoment(write, index + 3, existing.getDate().atTime(existing.getTime()));
        setMoment(write, index + 5, now);
        if (write.executeUpdate() == 0) {
            throw new IllegalStateException("This appointment changed or is no longer upcoming. Refresh the list.");
        }
    }

    private static SQLException bookingConflict(SQLiteException error) {
        if (error.getResultCode() == SQLiteErrorCode.SQLITE_CONSTRAINT_UNIQUE) {
            throw new IllegalStateException("This doctor is already booked at that date and time.", error);
        }
        return error;
    }

    private static void setMoment(PreparedStatement statement, int index, LocalDateTime moment)
            throws SQLException {
        statement.setString(index, moment.toLocalDate().toString());
        statement.setInt(index + 1, moment.getHour() * 60 + moment.getMinute());
    }

    private Connection open() throws SQLException {
        Connection connection = DriverManager.getConnection(url);
        try (Statement statement = connection.createStatement()) {
            statement.execute("PRAGMA busy_timeout = 2000");
            statement.execute("PRAGMA foreign_keys = ON");
            int pageLimit;
            try (ResultSet rows = statement.executeQuery("PRAGMA page_size")) {
                rows.next();
                pageLimit = MAX_DATABASE_BYTES / rows.getInt(1);
            }
            try (ResultSet rows = statement.executeQuery("PRAGMA max_page_count = " + pageLimit)) {
                rows.next();
                if (rows.getInt(1) > pageLimit) {
                    throw new SQLException("The clinic database exceeds 50 MB.");
                }
            }
            return connection;
        } catch (SQLException error) {
            try {
                connection.close();
            } catch (SQLException closeError) {
                error.addSuppressed(closeError);
            }
            throw error;
        }
    }

    private static void setPatientFields(PreparedStatement statement, String firstName, String lastName,
                                         String phone, String address) throws SQLException {
        statement.setString(1, firstName);
        statement.setString(2, lastName);
        statement.setString(3, phone);
        statement.setString(4, address);
    }

    private static Patient readPatient(ResultSet rows, int first) throws SQLException {
        return new Patient(rows.getInt(first), rows.getString(first + 1), rows.getString(first + 2),
                rows.getString(first + 3), rows.getString(first + 4));
    }

    private static Doctor readDoctor(ResultSet rows, int first) throws SQLException {
        return new Doctor(rows.getInt(first), rows.getString(first + 1), rows.getString(first + 2));
    }

    private static LocalTime fromMinute(int minute) {
        return LocalTime.of(minute / 60, minute % 60);
    }
}
